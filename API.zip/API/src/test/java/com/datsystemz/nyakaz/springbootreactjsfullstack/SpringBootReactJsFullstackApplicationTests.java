package com.datsystemz.nyakaz.springbootreactjsfullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootReactJsFullstackApplicationTests {

	@Test
	void contextLoads() {
	}

}
